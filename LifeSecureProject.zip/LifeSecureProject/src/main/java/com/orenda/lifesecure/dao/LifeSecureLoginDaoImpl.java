package com.orenda.lifesecure.dao;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

@Repository
@Transactional
public class LifeSecureLoginDaoImpl implements LifeSecureLoginDao {

	
@Autowired
SessionFactory sessionFactory;
	@Override
	public User verifyUser(String useremail) {
		System.out.println("daoo" + useremail);
		Session session = sessionFactory.openSession();

		Query query = session.createQuery("from User where email=?");

		User user = (User) query.setParameter(0, useremail).getSingleResult();

		System.out.println(user.toString());

		return user;
	}
	
	

	@Override
	public boolean saveUserData(UserDetails userdetails) {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		
		try {
		//session.save(user);
		//session.persist(user);
		session.saveOrUpdate(userdetails);
		tr.commit();
		return true;
		
		}catch(Exception e) {
			e.printStackTrace();
			tr.rollback();
			session.close();
			return false;
		}
		
	}



	@Override
	public boolean saveUsername(User user) {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		
		try {
			//session.save(user);
			//session.persist(user);
			session.saveOrUpdate(user);
			tr.commit();
			return true;
			
			}catch(Exception e) {
				e.printStackTrace();
				tr.rollback();
				session.close();
				return false;
			}
			
		
	}

}
