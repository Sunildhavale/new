package com.orenda.lifesecure.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.service.LifeSecureLoginService;

@Controller

public class LifeSecureLoginController {

	@Autowired
	LifeSecureLoginService loginService;

	@GetMapping("/")
	public String loginPage() {
		System.out.println("inside login");

		return "login";
	}

	@GetMapping("/verifyUser")
	public String verifyUser(@RequestParam("useremail") String useremail, @RequestParam("password") String password,
			Model model) {
		System.out.println(useremail + "" + password);
		///
		boolean flag = loginService.verifyUser(useremail, password);
		if (flag) {
			System.out.println("login success");

			return "login";
		}

		model.addAttribute("message", "Your user name and password is incorrect please try again::");
		return "login";
	}

	@GetMapping("/register")
	public ModelAndView registerPage() {
		System.out.println("registerpage () :::");
		ModelAndView model = null;
			 model =  new ModelAndView("registration", "user", new User());
		return model;
	}
	@PostMapping("/save")
	public String saveUserDetails(@ModelAttribute("userModel") User user,Model model) {
		
		System.out.println("user:: "+user.toString());
		boolean flag = loginService.saveUserDetails(user);
		//ModelAndView model = null;
		if(user.getId() > 0) {
			
			return "login";
		}
		return "registration";

	}
}
