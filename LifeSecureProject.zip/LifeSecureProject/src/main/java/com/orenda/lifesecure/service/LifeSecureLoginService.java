package com.orenda.lifesecure.service;

import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.model.UserDetails;

public interface LifeSecureLoginService {

	boolean verifyUser(String useremail, String password);

	boolean saveUserDetails(UserDetails userdetails);

}
