package com.orenda.lifesecure.service;

import com.orenda.lifesecure.model.User;

public interface LifeSecureLoginService {

	boolean verifyUser(String useremail, String password);

	boolean saveUserDetails(User user);

}
