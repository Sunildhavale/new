package com.orenda.lifesecure.service;

import java.util.List;

import com.orenda.lifesecure.model.User;

public interface LifeSecureLoginService {

	boolean verifyUser(String useremail, String password);

	List<User> getAllEmpList();



}
