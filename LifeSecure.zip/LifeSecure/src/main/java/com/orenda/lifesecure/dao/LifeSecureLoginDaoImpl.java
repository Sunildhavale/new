package com.orenda.lifesecure.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.orenda.lifesecure.model.Agent;
import com.orenda.lifesecure.model.User;

@Repository
@Transactional
public class LifeSecureLoginDaoImpl implements LifeSecureLoginDao {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public User verifyUser(String useremail) {
		System.out.println("daoo" + useremail);
		Session session = sessionFactory.openSession();

		Query query = session.createQuery("from User where email=?");

		User user = (User) query.setParameter(0, useremail).getSingleResult();

		System.out.println(user.toString());

		return user;
	}

	@Override
	public List<User> getAllEmplist() {
		// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			List<User> listEmp = session.createCriteria(Agent.class).list();
			return listEmp;
		}
	
	

	
	}

	
	
//	public boolean saveUserData(User user) {
//		Session session = sessionFactory.openSession();
//		Transaction tr = session.beginTransaction();
//		
//		try {
//		//session.save(user);
//		//session.persist(user);
//		session.saveOrUpdate(user);
//		tr.commit();
//		return true;
//		
//		}catch(Exception e) {
//			e.printStackTrace();
//			tr.rollback();
//			session.close();
//			return false;
//		}
//		
//	}


