package com.orenda.lifesecure.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orenda.lifesecure.dao.LifeSecureLoginDao;
import com.orenda.lifesecure.model.User;

@Service
public class LifeSecureLoginServiceImpl implements LifeSecureLoginService {

	@Autowired
	LifeSecureLoginDao loginDao;

	@Override
	public boolean verifyUser(String useremail, String password) {
		// TODO Auto-generated method stub

		User user = loginDao.verifyUser(useremail);
		System.out.println("service");

		if (user != null && user.getPassword().equals(password)) {
			return true;
		}

		return false;
	}

	@Override
	public List<User> getAllEmpList() {
		// TODO Auto-generated method stub
		return loginDao.getAllEmplist();
	}

	

//	public boolean saveUserDetails(User user) {
//
//		return loginDao.saveUserData(user);
//	}

}
