package com.orenda.lifesecure.constants;

public interface LifeSecureConstants {

}
