package com.orenda.lifesecure.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_login")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "login_id")
	private int id;
	@Column(name = "user_email")
	private String email;

	@Column(name = "user_password")
	private String password;
	@Column(name = "ip_address")
	private String ip_address;
	@Column(name = "last_login")
	private String last_login;
	@Column(name = "updated_time")
	private String updated_time;
	@Column(name = "is_active")
	private int is_active;
	@Column(name = "pass_valid_from")
	private LocalDate pass_valid_from;
	@Column(name = "pass_valid_till")
	private LocalDate pass_valid_till;
	
	@OneToOne(mappedBy = "User")
	private UserDetails userdetails;

	public User() {
	}

	public User(int id, String email, String password, String ip_address, String last_login, String updated_time,
			int is_active, LocalDate pass_valid_from, LocalDate pass_valid_till) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.ip_address = ip_address;
		this.last_login = last_login;
		this.updated_time = updated_time;
		this.is_active = is_active;
		this.pass_valid_from = pass_valid_from;
		this.pass_valid_till = pass_valid_till;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIp_address() {
		return ip_address;
	}

	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}

	public String getLast_login() {
		return last_login;
	}

	public void setLast_login(String last_login) {
		this.last_login = last_login;
	}

	public String getUpdated_time() {
		return updated_time;
	}

	public void setUpdated_time(String updated_time) {
		this.updated_time = updated_time;
	}

	public int getIs_active() {
		return is_active;
	}

	public void setIs_active(int is_active) {
		this.is_active = is_active;
	}

	public LocalDate getPass_valid_from() {
		return pass_valid_from;
	}

	public void setPass_valid_from(LocalDate pass_valid_from) {
		this.pass_valid_from = pass_valid_from;
	}

	public LocalDate getPass_valid_till() {
		return pass_valid_till;
	}

	public void setPass_valid_till(LocalDate pass_valid_till) {
		this.pass_valid_till = pass_valid_till;
	}
}
