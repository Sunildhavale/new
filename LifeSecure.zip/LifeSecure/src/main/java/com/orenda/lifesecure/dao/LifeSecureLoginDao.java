package com.orenda.lifesecure.dao;

import java.util.List;

import com.orenda.lifesecure.model.User;

public interface LifeSecureLoginDao {

	User verifyUser(String useremail);

	List<User> getAllEmplist();




	

}
