package com.orenda.lifesecure.dao;

import com.orenda.lifesecure.model.User;

public interface LifeSecureLoginDao {

	User verifyUser(String useremail);

	//boolean saveUserData(User user);

}
